package com.sistema.escola.models;

public class Curso {
	// Atributos
	private long codigoCurso;
	private int duracao;
	private String nomeCurso;
	private String turno;
	private Area area;
	
	// Construtor
	public Curso() {
		// TODO Auto-generated constructor stub
	}

	// Métodos de acesso
	public long getCodigoCurso() {
		return codigoCurso;
	}

	public void setCodigoCurso(long codigoCurso) {
		this.codigoCurso = codigoCurso;
	}

	public int getDuracao() {
		return duracao;
	}

	public void setDuracao(int duracao) {
		this.duracao = duracao;
	}

	public String getNomeCurso() {
		return nomeCurso;
	}

	public void setNomeCurso(String nomeCurso) {
		this.nomeCurso = nomeCurso;
	}

	public String getTurno() {
		return turno;
	}

	public void setTurno(String turno) {
		this.turno = turno;
	}

	public Area getArea() {
		return area;
	}

	public void setArea(Area area) {
		this.area = area;
	}

}
