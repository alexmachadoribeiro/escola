package com.sistema.escola.models;

public class Aluno {
	// Atributos
	private long matriculaAluno;
	private boolean responsavel;
	private String nomeAluno;
	private String sobrenomeAluno;
	private String cpf;
	private String email;
	private String nomeResponsavel;
	
	// Construtor
	public Aluno() {
		// TODO Auto-generated constructor stub
	}

}
