package com.sistema.escola.models;

public class Turma {
	//Atributos
	private long codigoTurma;
	private String turno;
	private Professor professor;
	private Curso curso;
	
	//Construtor
	public Turma() {
		// TODO Auto-generated constructor stub
	}

	// Métodos de acesso
	public long getCodigoTurma() {
		return codigoTurma;
	}

	public void setCodigoTurma(long codigoTurma) {
		this.codigoTurma = codigoTurma;
	}

	public String getTurno() {
		return turno;
	}

	public void setTurno(String turno) {
		this.turno = turno;
	}

	public Professor getProfessor() {
		return professor;
	}

	public void setProfessor(Professor professor) {
		this.professor = professor;
	}

	public Curso getCurso() {
		return curso;
	}

	public void setCurso(Curso curso) {
		this.curso = curso;
	}

}
