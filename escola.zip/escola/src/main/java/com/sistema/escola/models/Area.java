package com.sistema.escola.models;

public class Area {
	// Atributos
	private long codigoArea;
	private String nomeArea;
	private Professor professor;
	
	// Construtor
	public Area() {
		// TODO Auto-generated constructor stub
	}

	// Métodos de acesso
	public long getCodigoArea() {
		return codigoArea;
	}

	public void setCodigoArea(long codigoArea) {
		this.codigoArea = codigoArea;
	}

	public String getNomeArea() {
		return nomeArea;
	}

	public void setNomeArea(String nomeArea) {
		this.nomeArea = nomeArea;
	}

	public Professor getProfessor() {
		return professor;
	}

	public void setProfessor(Professor professor) {
		this.professor = professor;
	}

}
