package com.sistema.escola.models;

public class Professor {
	// Atributos
	private long matriculaProfessor;
	private String nome;
	private String sobrenome;
	private String email;
	private String cpf;
	private Area area;
	
	// Construtor
	public Professor() {
		// TODO Auto-generated constructor stub
	}

	// Métodos de acesso
	public long getMatriculaProfessor() {
		return matriculaProfessor;
	}

	public void setMatriculaProfessor(long matriculaProfessor) {
		this.matriculaProfessor = matriculaProfessor;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSobrenome() {
		return sobrenome;
	}

	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public Area getArea() {
		return area;
	}

	public void setArea(Area area) {
		this.area = area;
	}

}
